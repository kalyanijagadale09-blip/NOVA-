#!/usr/bin/env python3
"""
NOVA Recall - a voice study coach for students.

Point it at your notes. It turns them into questions, asks you aloud, listens
to your spoken answer, grades it, and brings weak cards back sooner
(spaced repetition, Leitner boxes). Works offline apart from speech recognition.

    python recall.py                 # quiz from ./notes (voice)
    python recall.py my_notes.md     # one file
    python recall.py --text          # keyboard mode, no microphone needed
    python recall.py --stats         # progress per topic

Supported note formats (mix freely, one item per line):
    # Topic heading                      -> sets the topic for what follows
    Q: question text / A: answer text    -> exact question and answer
    Term: definition   (or Term - def)   -> "What is Term?"
    Any other sentence of 6+ words       -> fill-in-the-blank question
"""

import argparse
import array
import collections
import datetime as dt
import difflib
import hashlib
import json
import random
import re
import sys
from pathlib import Path

STOPWORDS = set(
    "a an the of in on at to for and or is are was were be been being it its this that these those "
    "with as by from which who whom what when where how can could will would should may might do does "
    "did has have had into than then so such not no also their there they them his her he she we you i "
    "if but about over under between using used use called known more most other each any all both "
    "one two while until".split()
)
# Leitner boxes: days until a card is due again
INTERVALS = {1: 0, 2: 1, 3: 3, 4: 7, 5: 14, 6: 30}
MAX_BOX = 6


# --------------------------------------------------------------------------
# Voice I/O
# --------------------------------------------------------------------------
class Voice:
    """Mic input via sounddevice (no PyAudio / PortAudio install needed), speech via pyttsx3."""

    RATE = 16000
    CHUNK = 1600          # 100 ms of audio per read
    PAUSE_CHUNKS = 12     # 1.2 s of silence ends an answer (students pause while thinking)

    def __init__(self, text_mode: bool = False):
        self.text_mode = text_mode
        if text_mode:
            return
        try:
            import pyttsx3
            import sounddevice as sd
            import speech_recognition as sr
        except ImportError as exc:
            sys.exit(f"Missing dependency: {exc.name}. Run: pip install -r requirements.txt")
        self.sd, self.sr = sd, sr
        self.recognizer = sr.Recognizer()
        print("Calibrating for background noise (stay quiet for a second)...")
        try:
            with self._stream() as stream:
                levels = [self._rms(bytes(stream.read(self.CHUNK)[0])) for _ in range(10)]
        except Exception as exc:
            sys.exit(f"No usable microphone found ({exc}). Allow microphone access for Terminal, "
                     "or try: python recall.py --text")
        self.threshold = max(sum(levels) / len(levels) * 2.5, 400)
        self.engine = pyttsx3.init()
        self.engine.setProperty("rate", 170)

    def _stream(self):
        return self.sd.RawInputStream(samplerate=self.RATE, channels=1, dtype="int16", blocksize=self.CHUNK)

    @staticmethod
    def _rms(data: bytes) -> float:
        samples = array.array("h", data)
        if not samples:
            return 0.0
        return (sum(x * x for x in samples) / len(samples)) ** 0.5

    def say(self, text: str) -> None:
        print(f"RECALL: {text}")
        if not self.text_mode:
            self.engine.say(text.replace("_____", "blank"))
            self.engine.runAndWait()

    def listen(self, timeout: float = 12, phrase_limit: float = 30) -> str:
        if self.text_mode:
            try:
                return input("You: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                return "stop"

        max_wait, max_phrase = int(timeout * 10), int(phrase_limit * 10)
        pre = collections.deque(maxlen=3)   # keep a little audio from before speech starts
        frames, started, silent, waited = [], False, 0, 0
        with self._stream() as stream:
            while True:
                data = bytes(stream.read(self.CHUNK)[0])
                loud = self._rms(data) > self.threshold
                if not started:
                    pre.append(data)
                    if loud:
                        started, frames = True, list(pre)
                    else:
                        waited += 1
                        if waited >= max_wait:
                            return ""
                else:
                    frames.append(data)
                    silent = 0 if loud else silent + 1
                    if silent >= self.PAUSE_CHUNKS or len(frames) >= max_phrase:
                        break

        audio = self.sr.AudioData(b"".join(frames), self.RATE, 2)
        try:
            heard = self.recognizer.recognize_google(audio).lower()
            print(f"[heard] {heard}")
            return heard
        except self.sr.UnknownValueError:
            return ""
        except self.sr.RequestError:
            print("[speech service unavailable - check your internet, or say 'type' to type answers]")
            return ""

    def typed(self, prompt: str = "Type your answer: ") -> str:
        try:
            return input(prompt).strip().lower()
        except (EOFError, KeyboardInterrupt):
            return ""


# --------------------------------------------------------------------------
# Turning notes into cards
# --------------------------------------------------------------------------
def make_card(topic, kind, question, answer, term=None):
    cid = hashlib.md5(f"{question}|{answer}".encode()).hexdigest()[:10]
    return {"id": cid, "topic": topic, "kind": kind,
            "question": question.strip(), "answer": answer.strip(), "term": term}


def make_cloze(sentence: str):
    """Blank out the most 'important' word (longest non-stopword) of a sentence."""
    if len(sentence.split()) < 6:
        return None
    words = re.findall(r"[A-Za-z][A-Za-z\-']+", sentence)
    candidates = [w for w in words if w.lower() not in STOPWORDS and len(w) >= 5]
    if not candidates:
        return None
    target = max(candidates, key=len)
    question = re.sub(rf"\b{re.escape(target)}\b", "_____", sentence, count=1)
    return f"Fill in the blank: {question}", target


def parse_notes(path: Path) -> list:
    cards = []
    topic = path.stem.replace("_", " ").replace("-", " ").title()
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        i += 1
        if not line:
            continue
        if line.startswith("#"):
            topic = line.lstrip("#").strip() or topic
            continue

        q = re.match(r"(?i)^q\s*[:.)]\s*(.+)$", line)
        if q:
            while i < len(lines) and not lines[i].strip():
                i += 1
            if i < len(lines):
                a = re.match(r"(?i)^a\s*[:.)]\s*(.+)$", lines[i].strip())
                if a:
                    i += 1
                    cards.append(make_card(topic, "qa", q.group(1), a.group(1)))
            continue

        line = re.sub(r"^([-*\u2022]\s+|\d+[.)]\s+)", "", line)
        d = re.match(r"^([^:]{2,40}?)(?:\s*(?:::|:|\u2014|\u2013)\s+|\s+-\s+)(.{12,})$", line)
        if d and len(d.group(1).split()) <= 6:
            term = d.group(1).strip()
            cards.append(make_card(topic, "def", f"What is {term}?", d.group(2), term=term))
            continue

        cloze = make_cloze(line)
        if cloze:
            cards.append(make_card(topic, "cloze", cloze[0], cloze[1]))
    return cards


def load_cards(source: Path) -> list:
    if source.is_dir():
        files = sorted(p for p in source.rglob("*")
                       if p.suffix.lower() in {".txt", ".md"} and p.name.lower() != "readme.md")
    else:
        files = [source]
    seen, cards = set(), []
    for f in files:
        for card in parse_notes(f):
            if card["id"] not in seen:
                seen.add(card["id"])
                cards.append(card)
    return cards


# --------------------------------------------------------------------------
# Grading spoken answers
# --------------------------------------------------------------------------
def _stem(word: str) -> str:
    for suffix in ("ing", "ed", "es", "ly", "s"):
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            return word[: -len(suffix)]
    return word


def keywords(text: str) -> list:
    """List of (stem, original_word) for the meaningful words in text."""
    out = []
    for w in re.findall(r"[a-zA-Z0-9]+", text.lower()):
        if w in STOPWORDS or (len(w) <= 2 and not w.isdigit()):
            continue
        out.append((_stem(w), w))
    return out


def _matches(stem: str, pool: list) -> bool:
    return any(stem == p or difflib.SequenceMatcher(None, stem, p).ratio() >= 0.8 for p in pool)


def grade(card: dict, response: str):
    """Return (verdict, missed_words). verdict is 'correct', 'partial' or 'wrong'."""
    expected = list(dict(keywords(card["answer"])).items())  # unique by stem
    if not expected:
        return "wrong", []
    given = [stem for stem, _ in keywords(response)]
    missed = [orig for stem, orig in expected if not _matches(stem, given)]
    score = 1 - len(missed) / len(expected)
    if score >= 0.6:
        return "correct", missed
    if score >= 0.3:
        return "partial", missed
    return "wrong", missed


def make_hint(card: dict, level: int) -> str:
    kws = [orig for _, orig in keywords(card["answer"])]
    if not kws:
        return "Think about the definition in your notes."
    first = kws[0]
    if card["kind"] == "cloze":
        if level == 1:
            return f"It starts with the letter {first[0]} and has {len(first)} letters."
        return f"It starts with {first[:3]}."
    if level == 1:
        return f"The answer has {len(kws)} key terms. One starts with the letter {first[0]}."
    return f"One key term is {first}."


# --------------------------------------------------------------------------
# Progress (spaced repetition)
# --------------------------------------------------------------------------
class Progress:
    def __init__(self, path: Path):
        self.path = path
        try:
            self.data = json.loads(path.read_text())
        except (OSError, ValueError):
            self.data = {}

    def is_due(self, cid: str) -> bool:
        s = self.data.get(cid)
        return bool(s) and s["due"] <= dt.date.today().isoformat()

    def update(self, cid: str, verdict: str) -> None:
        s = self.data.get(cid, {"box": 1, "seen": 0, "correct": 0})
        s["seen"] += 1
        if verdict == "correct":
            s["box"] = min(MAX_BOX, s["box"] + 1)
            s["correct"] += 1
        elif verdict == "wrong":
            s["box"] = 1
        s["due"] = (dt.date.today() + dt.timedelta(days=INTERVALS[s["box"]])).isoformat()
        self.data[cid] = s

    def save(self) -> None:
        try:
            self.path.write_text(json.dumps(self.data, indent=1))
        except OSError as exc:
            print(f"[could not save progress: {exc}]")


def pick_cards(cards, progress, count, topic=None, ignore_schedule=False):
    pool = [c for c in cards if not topic or topic.lower() in c["topic"].lower()]
    if ignore_schedule:
        chosen = pool[:]
        random.shuffle(chosen)
        return chosen[:count]
    due = [c for c in pool if progress.is_due(c["id"])]
    due.sort(key=lambda c: progress.data[c["id"]]["box"])  # weakest first
    new = [c for c in pool if c["id"] not in progress.data]
    random.shuffle(new)
    chosen = (due + new)[:count]
    random.shuffle(chosen)
    return chosen


# --------------------------------------------------------------------------
# The quiz session
# --------------------------------------------------------------------------
COMMANDS = {
    "stop": {"stop", "quit", "exit", "end session", "end the session", "that's enough", "thats enough"},
    "hint": {"hint", "clue", "give me a hint", "help me"},
    "repeat": {"repeat", "again", "say that again", "repeat the question"},
    "skip": {"skip", "next", "pass", "skip this"},
    "giveup": {"i don't know", "i dont know", "don't know", "dont know", "show answer",
               "tell me the answer", "give up", "no idea", "show me the answer"},
    "type": {"type", "type it", "let me type", "i'll type"},
}


def command_of(reply: str):
    r = reply.strip(" .!?,")
    for name, phrases in COMMANDS.items():
        if r in phrases:
            return name
    return None


def ask_card(voice: Voice, card: dict, number: int):
    """Ask one card. Returns (verdict, stop_requested)."""
    voice.say(f"Question {number}. {card['topic']}. {card['question']}")
    hints = silent = 0
    while True:
        reply = voice.listen()
        if not reply:
            silent += 1
            if silent >= 3:
                voice.say(f"Moving on. The answer was: {card['answer']}")
                return "wrong", False
            voice.say("I didn't catch that. Answer, or say hint, repeat, skip or I don't know.")
            continue

        cmd = command_of(reply)
        if cmd == "stop":
            return None, True
        if cmd == "skip":
            voice.say("Skipped.")
            return None, False
        if cmd == "repeat":
            voice.say(card["question"])
            continue
        if cmd == "hint":
            hints += 1
            voice.say(make_hint(card, min(hints, 2)))
            continue
        if cmd == "giveup":
            voice.say(f"No problem. The answer is: {card['answer']}")
            return "wrong", False
        if cmd == "type":
            reply = voice.typed()
            if not reply:
                continue

        verdict, missed = grade(card, reply)
        if verdict == "correct" and hints:
            verdict = "partial"  # needed help, so it should come back sooner
        if verdict == "correct":
            voice.say(random.choice(["Correct!", "That's right.", "Spot on."]))
        elif verdict == "partial":
            if missed:
                voice.say(f"Partly right. You missed: {', '.join(missed[:4])}. Full answer: {card['answer']}")
            else:
                voice.say(f"Good, with a little help. Full answer: {card['answer']}")
        else:
            voice.say(f"Not quite. The answer is: {card['answer']}")
        return verdict, False


def run_session(voice: Voice, chosen: list, progress: Progress) -> None:
    voice.say(f"Starting a session with {len(chosen)} questions. "
              "Say hint, repeat, skip, I don't know, type, or stop at any time.")
    results = []  # (card, verdict)
    for number, card in enumerate(chosen, 1):
        verdict, stop = ask_card(voice, card, number)
        if stop:
            break
        if verdict:
            progress.update(card["id"], verdict)
            results.append((card, verdict))
        progress.save()

    if not results:
        voice.say("Session ended. No questions were graded.")
        return
    right = sum(v == "correct" for _, v in results)
    weak = {}
    for card, verdict in results:
        if verdict != "correct":
            weak[card["topic"]] = weak.get(card["topic"], 0) + 1
    msg = f"Session complete. You got {right} of {len(results)} fully right."
    if weak:
        worst = sorted(weak, key=weak.get, reverse=True)[:3]
        msg += " Review these topics: " + ", ".join(worst) + "."
    else:
        msg += " Excellent work, nothing to review."
    voice.say(msg)


def print_stats(cards: list, progress: Progress) -> None:
    rows = {}
    for c in cards:
        r = rows.setdefault(c["topic"], {"cards": 0, "new": 0, "due": 0, "mastered": 0})
        r["cards"] += 1
        s = progress.data.get(c["id"])
        if not s:
            r["new"] += 1
            continue
        if progress.is_due(c["id"]):
            r["due"] += 1
        if s["box"] >= 5:
            r["mastered"] += 1
    print(f"{'Topic':<32}{'Cards':>6}{'New':>6}{'Due':>6}{'Mastered':>10}")
    for topic, r in rows.items():
        print(f"{topic[:31]:<32}{r['cards']:>6}{r['new']:>6}{r['due']:>6}{r['mastered']:>10}")
    print(f"\nTotal cards: {len(cards)}")


# --------------------------------------------------------------------------
def main() -> None:
    ap = argparse.ArgumentParser(description="NOVA Recall - voice quiz from your notes")
    ap.add_argument("notes", nargs="?", default="notes", help="notes file or folder (.txt/.md), default: ./notes")
    ap.add_argument("-n", "--count", type=int, default=10, help="questions per session (default 10)")
    ap.add_argument("--topic", help="only quiz topics containing this text")
    ap.add_argument("--all", action="store_true", help="ignore the review schedule")
    ap.add_argument("--text", action="store_true", help="keyboard mode instead of voice")
    ap.add_argument("--stats", action="store_true", help="show progress per topic and exit")
    args = ap.parse_args()

    source = Path(args.notes)
    if not source.exists():
        sys.exit(f"Notes not found: {source}. Put your .txt/.md notes in a 'notes' folder.")
    cards = load_cards(source)
    if not cards:
        sys.exit("No questions could be made from those notes. See the formats at the top of recall.py.")

    folder = source if source.is_dir() else source.parent
    progress = Progress(folder / ".recall_progress.json")

    if args.stats:
        print_stats(cards, progress)
        return

    chosen = pick_cards(cards, progress, args.count, args.topic, args.all)
    if not chosen:
        print("You're all caught up: nothing is due. Run with --all to practise anyway.")
        return

    voice = Voice(args.text)
    try:
        run_session(voice, chosen, progress)
    except KeyboardInterrupt:
        progress.save()
        print("\nSession stopped. Progress saved.")


if __name__ == "__main__":
    main()
