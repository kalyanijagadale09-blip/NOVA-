# NOVA Recall: Voice Study Coach for Students

Most notes apps store your notes. **NOVA Recall tests you on them.**
Point it at your lecture notes and it asks you questions aloud, listens to your spoken answer, grades it, and brings the topics you're weak on back sooner, so you practise *active recall* instead of just re-reading.

```
Notes → Question Generation → Spoken Question → Spoken Answer → Speech-to-Text
      → Answer Grading → Spoken Feedback → Spaced-Repetition Schedule
```

## Why it's different from a general voice assistant
| Feature | How it works |
|---|---|
| Auto-generated questions | Turns your own notes into questions: Q/A pairs, definitions, fill-in-the-blank |
| Spoken answers, graded by meaning | Keyword matching with stemming and fuzzy matching, so speech-recognition slips still count |
| Three grades | Correct, Partly right (tells you the missing terms), Wrong (reads the answer) |
| Hints | "Hint" gives the first letter, then a key term. Using hints means the card returns sooner |
| Spaced repetition | Leitner boxes: right answers return after 1, 3, 7, 14, 30 days; wrong ones come back next session |
| Session report | Speaks your score and the topics to review |
| Progress stats | `--stats` shows new / due / mastered cards per topic |
| Works offline | Question making and grading are local; only speech-to-text uses the internet |

## Setup
```bash
pip install -r requirements.txt
```
Microphone input uses `sounddevice`, which bundles its own audio engine on Windows and macOS, so no PyAudio or Homebrew is needed. On Linux run `sudo apt install libportaudio2 espeak` first.

## Write notes
Put `.txt` or `.md` files in the `notes/` folder. Mix these freely, one item per line:

```
# Operating Systems                      <- heading sets the topic
Deadlock: processes waiting forever...   <- becomes "What is Deadlock?"
Stack - a linear structure that...       <- same, with a dash
Q: What are the conditions for deadlock? <- exact question
A: Mutual exclusion, hold and wait...    <- and its answer
Paging divides memory into frames.       <- any sentence of 6+ words becomes fill-in-the-blank
```
Tip: define one idea per line and keep answers short and keyword-rich.

## Run
```bash
python recall.py                  # voice quiz from ./notes
python recall.py --text           # keyboard mode (no microphone)
python recall.py -n 20            # 20 questions
python recall.py --topic "data"   # only matching topics
python recall.py --all            # ignore the schedule, practise everything
python recall.py --stats          # progress per topic
```

## Voice commands during a quiz
`hint` · `repeat` · `skip` · `I don't know` · `type` (type the answer instead) · `stop`

## Project structure
- `recall.py`: whole application (voice I/O, note parser, grader, scheduler, session loop)
- `notes/`: your notes (a sample is included)
- `.recall_progress.json`: created automatically; stores your schedule (git-ignored)

## Ideas to extend
Add a mobile-friendly web UI, import slides or PDFs as notes, an "explain it like I'm teaching" (Feynman) mode, exam countdown planning, or an LLM grader for long free-form answers.
